#ifndef HW06_MEM_H
#define HW06_MEM_H

#include <stdint.h>

void* hw06_malloc(uint64_t size);
void hw06_free();

#endif
