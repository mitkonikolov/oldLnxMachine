#include "hw06_mem.h"

void*
hw06_malloc(uint64_t size)
{
    // TODO: Insert hw06 allocator here.
    return 0;
}

void
hw06_free(void* addr)
{
    // TODO: insert hw06 free here.
}

