
#include <stdlib.h>

#include "hw06_mem.h"

void* 
nu_malloc(size_t size)
{
    // TODO: Allocate memory using a technique optimized
    //       for sizeof(struct icell) allocations.
    // if (is_icell(size)) {
    //    return alloc_icell(...);
    // }
    // else {
    return hw06_malloc(size);
}

void 
nu_free(void* ptr)
{
    // TODO: Optimized deallocation.
    hw06_free(ptr);
}
