#ifndef INT128_H
#define INT128_H

typedef __int128_t int128_t;

int128_t atoh(char* text);
void print_int128(int128_t xx);

#endif
